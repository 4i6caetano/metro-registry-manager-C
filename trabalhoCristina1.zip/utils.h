#ifndef UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "header.h"
#include "registry.h"
#include "functionalities.h"

/**
 * Nome completo: João Pedro Correia Caetano
 * NUSP - 16987067
 * Bacharelado de Sistemas de Informação
 * Esse código também está disponível no github! Caso queiram ver as mudanças durante o desenvolvimento, melhorias e, no geral, o processo de criação do projeto do zero, tudo estará nos commits! Usei somente a branch 'main' no projeto.
 * Decidi escrever a documentação em inglês, assim como suas variáveis, para deixar o código mais portável e profissional. Entretanto, manti todos os nomes dados no documento do jeito que estavam, assim como a estrutura de todas as funções e projeto no geral.
 * 
 * Caso queiram dar uma olhada, acessem por aqui: https://github.com/4i6caetano/metro-registry-manager-C
 * (O código é igual aos que vocês vêem).
 */

#define BINARY_TO_REGISTRY_SUCESS 1
#define BINARY_TO_REGISTRY_FAILURE 0

void BinarioNaTela(char *arquivo);
void ScanQuoteString(char *str);

/**
 * @brief getToken() is used as a substitute with some additions to the function strtok(), as it was made to include the reading of 'null' elements in the .csv file.
 * 
 * This function pick up the data from the .csv file and save it into a buffer.
 */
char* getToken(char** buffer);

#endif